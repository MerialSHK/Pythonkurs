# 🎮 Algorithmics Python Play - Kurs

Willkommen zum Python Play Kurs! Hier findest du alles was du brauchst.

---

## 🚀 Erste Schritte (Setup)

### 1. Dieses Repo herunterladen
```
git clone https://github.com/DEIN-USERNAME/algorithmics-play.git
cd algorithmics-play
```

### 2. Setup ausführen
**Windows:** Doppelklick auf `setup.bat`

**Oder in der Eingabeaufforderung (cmd):**
```
setup.bat
```

### 3. Testen
```
python test_setup.py
```
Wenn ein Fenster mit einem roten Kreis aufgeht, den du mit den Pfeiltasten bewegen kannst → alles funktioniert! ✅

---

## 📂 Ordnerstruktur

```
algorithmics-play/
├── README.md              ← Diese Datei
├── setup.bat              ← Setup-Script (1x ausführen)
├── requirements.txt       ← Benötigte Pakete
├── test_setup.py          ← Test ob alles funktioniert
│
└── projekte/
    ├── 01_erste_app/      ← Lektion 1: Erstes Play-Fenster
    ├── 02_sprites/        ← Lektion 1: Sprites erstellen
    ├── 03_bewegung/       ← Lektion 1: Sprite bewegen
    ├── 04_spielfeld/      ← Lektion 1: Spielfeldgrenzen
    ├── 05_maze/           ← Lektion 2: Maze mit Physik
    └── 06_slot_machine/   ← Projekt: Slot Machine
```

---

## ❓ Probleme?

| Problem | Lösung |
|---------|--------|
| `python` wird nicht erkannt | Versuche `python3` oder frage den Lehrer |
| "No module named play" | `setup.bat` nochmal ausführen |
| Fenster öffnet sich nicht | Code prüfen: `play.start_program()` am Ende? |
