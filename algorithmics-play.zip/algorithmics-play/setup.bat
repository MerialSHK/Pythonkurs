@echo off
chcp 65001 >NUL 2>&1
echo.
echo  =============================================
echo   Algorithmics Python Play - Setup
echo  =============================================
echo.

REM --- Python finden ---
set PYTHON_CMD=

REM Versuch 1: python
python --version >NUL 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    goto :found_python
)

REM Versuch 2: python3
python3 --version >NUL 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python3
    goto :found_python
)

REM Versuch 3: py launcher
py --version >NUL 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    goto :found_python
)

REM Python nicht gefunden
echo  [FEHLER] Python wurde nicht gefunden!
echo.
echo  Moegliche Loesungen:
echo    1. Python installieren: https://www.python.org/downloads/
echo       WICHTIG: "Add Python to PATH" anhaken!
echo    2. Python aus dem Microsoft Store installieren
echo    3. Den Lehrer fragen
echo.
pause
exit /b 1

:found_python
echo  Python gefunden: %PYTHON_CMD%
%PYTHON_CMD% --version
echo.

REM --- pip pruefen ---
%PYTHON_CMD% -m pip --version >NUL 2>&1
if errorlevel 1 (
    echo  pip nicht gefunden, versuche Installation...
    %PYTHON_CMD% -m ensurepip --default-pip 2>NUL
    %PYTHON_CMD% -m pip --version >NUL 2>&1
    if errorlevel 1 (
        echo  [FEHLER] pip konnte nicht installiert werden.
        echo  Bitte den Lehrer fragen.
        pause
        exit /b 1
    )
)
echo  pip gefunden.
echo.

REM --- Pakete installieren ---
echo  [1/3] pip aktualisieren...
%PYTHON_CMD% -m pip install --upgrade pip --user 2>NUL
if errorlevel 1 (
    %PYTHON_CMD% -m pip install --upgrade pip 2>NUL
)

echo.
echo  [2/3] pygame installieren...
%PYTHON_CMD% -m pip install pygame --user 2>NUL
if errorlevel 1 (
    echo         Versuche ohne --user...
    %PYTHON_CMD% -m pip install pygame 2>NUL
)

echo.
echo  [3/3] replit-play installieren...
%PYTHON_CMD% -m pip install replit-play --user 2>NUL
if errorlevel 1 (
    echo         Versuche ohne --user...
    %PYTHON_CMD% -m pip install replit-play 2>NUL
)

REM --- Testen ---
echo.
echo  =============================================
echo   Test...
echo  =============================================
echo.

%PYTHON_CMD% -c "import play; print('  ERFOLG! Play ist installiert und funktioniert!')" 2>NUL
if errorlevel 1 (
    echo.
    echo  [FEHLER] Play konnte nicht importiert werden.
    echo.
    echo  Installierte Pakete:
    %PYTHON_CMD% -m pip list --user 2>NUL
    echo.
    echo  Bitte den Lehrer um Hilfe.
) else (
    echo.
    echo  =============================================
    echo   Alles bereit! Du kannst jetzt loslegen.
    echo   Teste mit: %PYTHON_CMD% test_setup.py
    echo  =============================================
)

echo.
pause
