# 05 - Maze (Labyrinth) mit Physik
# Aufgabe:
#   1. Erstelle einen Spieler (Kreis) unten in der Mitte
#   2. Erstelle mindestens 6 Hindernisse (Rechtecke)
#   3. Erstelle einen Zielpunkt oben ("finish")
#   4. Schalte Physik ein fuer Spieler und Hindernisse
#   5. Bewege den Spieler mit W/A/S/D
#   6. Wenn der Spieler das Ziel beruehrt → "YOU WIN!"
#
# Nuetzliche Befehle:
#   sprite.start_physics(bounciness=0.2)      → Physik ein (beweglich)
#   sprite.start_physics(can_move=False)       → Physik ein (fest)
#   player.physics.y_speed = 10               → Geschwindigkeit setzen
#   player.is_touching(anderer_sprite)         → Beruehrung pruefen
#   sprite.hide()                              → Sprite verstecken

import play

frames = 48   # Bildwiederholrate
step = 10     # Bewegungsgeschwindigkeit

# --- Spieler ---
player = play.new_circle(
    color='red', x=0, y=-270,
    radius=20, border_color='light green'
)

# --- Hindernisse ---
# Erstelle hier deine Waende!
# Beispiel:
# wall1 = play.new_box(color='black', x=0, y=0, width=100, height=10)
# wall2 = play.new_box(color='black', x=-50, y=10, width=10, height=100)
# ... mindestens 6 Stueck!

# --- Zielpunkt ---
finish = play.new_text(
    words='finish', x=0, y=270,
    font=None, font_size=50
)

@play.when_program_starts
def start():
    # Physik einschalten:
    player.start_physics(bounciness=0.2)
    # wall1.start_physics(can_move=False)
    # wall2.start_physics(can_move=False)
    # ... fuer jede Wand!
    pass

@play.repeat_forever
async def game():
    # Geschwindigkeit auf 0 setzen (Stillstand wenn keine Taste)
    player.physics.x_speed = 0
    player.physics.y_speed = 0

    # Steuerung mit W/A/S/D
    if play.key_is_pressed('w', 'up'):
        player.physics.y_speed = step
    if play.key_is_pressed('s', 'down'):
        player.physics.y_speed = -1 * step
    if play.key_is_pressed('a', 'left'):
        player.physics.x_speed = -1 * step
    if play.key_is_pressed('d', 'right'):
        player.physics.x_speed = step

    # --- Ziel erreicht? ---
    # if player.is_touching(finish):
    #     wall1.hide()
    #     wall2.hide()
    #     ... alle Waende verstecken
    #     finish.hide()
    #     play.new_text(words='YOU WIN!', x=0, y=0,
    #                   font=None, font_size=100, color='yellow')

    await play.timer(seconds=1/frames)

play.start_program()
