# 05 - Maze (Labyrinth)
Erstelle ein Labyrinth mit Physik! Der Spieler muss zum Ziel navigieren.
Nutze `start_physics()`, `physics.x_speed`, `is_touching()`.
