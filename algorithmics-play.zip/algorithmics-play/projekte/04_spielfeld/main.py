# 04 - Spielfeldgrenzen
# Aufgabe: Der Sprite darf nicht aus dem Fenster verschwinden!
#
# Nuetzliche Befehle:
#   play.screen.width  → Breite des Fensters
#   play.screen.height → Hoehe des Fensters
#   abs(zahl)          → Gibt den positiven Wert zurueck

import play

# Fenstergrenzen berechnen
w = play.screen.width / 2
h = play.screen.height / 2

# Sprite erstellen
text = play.new_text(words='O___o', x=0, y=0, font=None, font_size=40)

@play.when_program_starts
def start():
    pass

@play.repeat_forever
def do():
    # Bewegung
    if play.key_is_pressed('up'):
        text.y = text.y + 5
    if play.key_is_pressed('down'):
        text.y = text.y - 5
    if play.key_is_pressed('left'):
        text.x = text.x - 5
    if play.key_is_pressed('right'):
        text.x = text.x + 5

    # --- Grenzen setzen ---
    # Tipp: Wenn der Sprite oben am Rand ist UND y positiv ist,
    #       dann schiebe ihn 10 Pixel zurueck.
    #
    # if abs(text.y) >= h and text.y > 0:
    #     text.y = text.y - 10
    #
    # Mach das gleiche fuer: unten, links, rechts
    pass

play.start_program()
