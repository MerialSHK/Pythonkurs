# 04 - Spielfeldgrenzen
Der Sprite soll nicht aus dem Fenster verschwinden!
Nutze `play.screen.width`, `play.screen.height` und `abs()`.
