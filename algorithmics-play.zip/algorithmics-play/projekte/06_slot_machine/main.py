# 06 - Slot Machine
# Aufgabe:
#   1. Begruessung und "Spin"-Button anzeigen
#   2. Beim Klick auf "Spin": 3 Zufallszahlen generieren
#   3. Wenn alle 3 Zahlen gleich → "Du gewinnst!"
#   4. Sonst → "Verloren! Versuch es nochmal."
#   5. Optional: Fehlversuch-Zaehler
#   6. Optional: Muenz-Zaehler (Start: 50, Spin: -5, Gewinn: +100)
#
# Nuetzliche Befehle:
#   from random import randint
#   randint(0, 9)                → Zufallszahl 0-9
#   str(zahl)                    → Zahl in Text umwandeln
#   int(text)                    → Text in Zahl umwandeln
#   @button.when_clicked         → Klick auf Sprite
#   await play.timer(seconds=2)  → 2 Sekunden warten
#   sprite.show() / sprite.hide()

import play
from random import randint

# --- Oberflaeche erstellen ---

# 3 gruene Bloecke fuer die Zahlen
place1 = play.new_box(color='light green', x=0, y=0,
    width=100, height=200, border_width=5, border_color='green')
place2 = play.new_box(color='light green', x=0, y=0,
    width=100, height=200, border_width=5, border_color='green')
place3 = play.new_box(color='light green', x=0, y=0,
    width=100, height=200, border_width=5, border_color='green')

# Begruessung
hello = play.new_text(
    words='Hallo! Klicke den Button um dein Glueck zu versuchen!',
    x=0, y=0, font=None, font_size=40, color='green'
)

# Ergebnis-Text
result = play.new_text(
    words='', x=0, y=0,
    font=None, font_size=40, color='green'
)

# Spin-Button (Rechteck + Text)
button = play.new_box(color='yellow', x=0, y=0, width=150, height=50)
button_text = play.new_text(words='Spin!', x=0, y=0, font=None, font_size=50)

# 3 Text-Sprites fuer die Zufallszahlen
num1_text = play.new_text(words='', x=-200, y=0, font=None, font_size=100)
num2_text = play.new_text(words='', x=0, y=0, font=None, font_size=100)
num3_text = play.new_text(words='', x=200, y=0, font=None, font_size=100)


# --- Programm-Start ---
@play.when_program_starts
def start():
    # Bloecke positionieren
    place1.x = -200
    place2.x = 0
    place3.x = 200

    # Texte positionieren
    hello.y = 250
    result.y = -250
    button.y = 170
    button_text.y = 170

    # Zahlen und Ergebnis verstecken
    num1_text.hide()
    num2_text.hide()
    num3_text.hide()
    result.hide()


# --- Klick auf den Spin-Button ---
@button.when_clicked
async def clicking():
    # 3 Zufallszahlen generieren
    num1 = randint(0, 9)
    num2 = randint(0, 9)
    num3 = randint(0, 9)

    # Zahlen anzeigen (Zahl → Text mit str())
    num1_text.words = str(num1)
    num2_text.words = str(num2)
    num3_text.words = str(num3)

    num1_text.show()
    num2_text.show()
    num3_text.show()

    # --- Gewonnen oder verloren? ---
    # Tipp: if num1 == num2 and num2 == num3:
    #           result.words = 'Du gewinnst!'
    #       else:
    #           result.words = 'Verloren! Versuch es nochmal.'

    result.show()

    # 2 Sekunden warten, dann alles verstecken
    await play.timer(seconds=2.0)
    num1_text.hide()
    num2_text.hide()
    num3_text.hide()
    result.hide()


@play.repeat_forever
def do():
    pass

play.start_program()
