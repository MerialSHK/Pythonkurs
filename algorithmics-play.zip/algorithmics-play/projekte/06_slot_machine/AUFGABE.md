# 06 - Slot Machine
Baue einen Spielautomaten! 3 Zufallszahlen, Gewinn bei 3 gleichen.
Optional: Fehlversuch-Zähler und Münz-System.
