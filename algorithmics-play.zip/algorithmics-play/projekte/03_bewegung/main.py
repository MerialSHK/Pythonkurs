# 03 - Sprite bewegen
# Aufgabe: Bewege einen Sprite mit den Pfeiltasten
#   - Pfeil hoch    → Sprite geht nach oben   (y + 5)
#   - Pfeil runter  → Sprite geht nach unten  (y - 5)
#   - Pfeil links   → Sprite geht nach links  (x - 5)
#   - Pfeil rechts  → Sprite geht nach rechts (x + 5)
#
# Nuetzlicher Befehl: play.key_is_pressed('up')

import play

# Erstelle einen Sprite den du bewegen willst
text = play.new_text(words='O___o', x=0, y=0, font=None, font_size=40)

@play.when_program_starts
def start():
    pass

@play.repeat_forever
def do():
    # --- Schreibe hier die Steuerung ---
    # Tipp: if play.key_is_pressed('up'):
    #           text.y = text.y + 5
    pass

play.start_program()
