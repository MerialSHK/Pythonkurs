# 03 - Sprite bewegen
Bewege einen Sprite mit den Pfeiltasten hoch/runter/links/rechts.
Nutze `play.key_is_pressed('up')` und ändere `sprite.x` bzw `sprite.y`.
