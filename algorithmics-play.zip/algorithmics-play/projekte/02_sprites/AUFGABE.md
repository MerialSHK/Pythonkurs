# 02 - Sprites erstellen
1. Erstelle einen Text-Sprite
2. Erstelle einen grünen Kreis (Radius 10) rechts unten
3. Erstelle ein Bild-Sprite oben in der Mitte (optional)
4. Verstecke 2 Sprites mit `.hide()`
