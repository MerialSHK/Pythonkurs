# 02 - Sprites erstellen
# Aufgabe:
#   1. Erstelle einen Text-Sprite mit beliebigem Inhalt
#   2. Erstelle einen gruenen Kreis (Radius 10) rechts unten
#   3. Erstelle ein Bild-Sprite (optional) oben in der Mitte
#   4. Verstecke 2 Sprites (nicht loeschen!)

import play

# --- Erstelle hier deine Sprites ---
# Beispiel Text-Sprite:
# text = play.new_text(words='Hallo!', x=0, y=0, font=None, font_size=40)

# Beispiel Kreis-Sprite:
# kreis = play.new_circle(color='green', x=300, y=-250, radius=10)

# Beispiel Rechteck-Sprite:
# box = play.new_box(color='blue', x=0, y=100, width=100, height=50)


# Beim Start: Sprites verstecken
@play.when_program_starts
def start():
    # Beispiel: text.hide()
    pass

@play.repeat_forever
def do():
    pass

play.start_program()
