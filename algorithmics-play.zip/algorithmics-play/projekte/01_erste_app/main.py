# 01 - Meine erste Play-Anwendung
# Aufgabe: Erstelle ein leeres Play-Fenster
# 
# Schritte:
#   1. Play-Bibliothek importieren
#   2. Zwei Sektionen erstellen
#   3. Programm starten

# Bibliothek importieren
import play

# Aktionen die 1x beim Start ausgefuehrt werden
@play.when_program_starts
def start():
    pass

# Aktionen die dauerhaft wiederholt werden
@play.repeat_forever
def do():
    pass

# Programm starten
play.start_program()
