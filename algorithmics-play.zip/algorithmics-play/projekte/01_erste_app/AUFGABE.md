# 01 - Erste Play-Anwendung
Erstelle ein leeres Play-Fenster. Wenn sich ein graues Fenster öffnet, hast du es geschafft!
