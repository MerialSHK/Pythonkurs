# test_setup.py - Teste ob Python Play funktioniert
# Fuehre aus mit: python test_setup.py

import play

# Hintergrund-Info
info = play.new_text(
    words='Setup OK! Bewege den Kreis mit den Pfeiltasten.',
    x=0, y=200,
    font=None, font_size=25, color='green'
)

# Spielfigur
player = play.new_circle(
    color='red', x=0, y=0, radius=25
)

# Test-Box
box = play.new_box(
    color='light green', x=150, y=0,
    width=60, height=60,
    border_width=3, border_color='green'
)

# Hinweis unten
hinweis = play.new_text(
    words='Fenster schliessen zum Beenden.',
    x=0, y=-200,
    font=None, font_size=18, color='gray'
)

@play.when_program_starts
def start():
    pass

@play.repeat_forever
def do():
    if play.key_is_pressed('up'):
        player.y = player.y + 3
    if play.key_is_pressed('down'):
        player.y = player.y - 3
    if play.key_is_pressed('left'):
        player.x = player.x - 3
    if play.key_is_pressed('right'):
        player.x = player.x + 3

play.start_program()
